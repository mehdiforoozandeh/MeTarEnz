from .pfcodes.atc_wp import atc_wp as atc
from .pfcodes.boc_wp import boc_wp as boc
from .pfcodes.ddor_wp import ddor_wp as ddor
from .pfcodes.pcp_wp import pcp_wp as pcp
from .pfcodes.rri_wp import rri_wp as rri
from .pfcodes.sep_wp import sep_wp as sep
from .pfcodes.ser_wp import ser_wp as ser
from .pfcodes.se_wp import se
from .codes import *
import random, string, os, sys, re
import pandas as pd
import numpy as np


def write_seq_to_file(seq): #for pFeat

	rand = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(7))
	with open('temp/'+rand+'.fasta', 'w') as temp_seq_file:
		temp_seq_file.write(seq)
	return 'temp/' + rand + '.fasta'

def write_seq_to_file_2(seq): #for iFeat
	
	rand = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(7))
	with open('temp/'+rand+'.fasta', 'w') as temp_seq_file:
		temp_seq_file.write('>'+rand+'\n'+seq)
	return 'temp/' + rand + '.fasta'

def read_res_from_file(file):

	return pd.read_csv(file)

# arguments for all features: "file, outt"
def Pfeat(seq, feat):
	
	inp_file = write_seq_to_file(seq)
	out_file = inp_file.replace('fasta','csv')
	
	if feat == 'atc':
		atc(inp_file, out_file)
		val = read_res_from_file(out_file)
		val.columns = ['atc_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'boc':
		boc(inp_file, out_file)
		val = read_res_from_file(out_file)
		val.columns = ['boc_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'ddor':
		ddor(inp_file, out_file)
		val = read_res_from_file(out_file)
		val = val.drop('Unnamed: 20', axis=1)
		val.columns = ['ddor_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'pcp':
		val = pd.DataFrame(np.array(pcp(inp_file, out_file)))
		new_header = list(val.iloc[0])
		val = val[1:]
		val.columns = new_header
		val = val.reset_index()
		val = val.drop('index', axis=1)
		val.columns = ['pcp_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'rri':
		rri(inp_file, out_file)
		val = read_res_from_file(out_file)
		val = val.drop('Unnamed: 20', axis=1)
		val.columns = ['rri_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'sep':
		val = pd.DataFrame(np.array(sep(inp_file, out_file)))
		new_header = list(val.iloc[0])
		val = val[1:]
		val.columns = new_header
		val = val.reset_index()
		val = val.drop('index', axis=1)
		val.columns = ['sep_'+str(val.columns[i]) for i in range(len(val.columns))]

	elif feat == 'ser':
		val = pd.DataFrame(np.array(ser(inp_file, out_file)))
		val.columns = ['ser_'+str(i) for i in range(val.shape[1])]

	elif feat == 'se':
		val = pd.DataFrame(np.array(se(inp_file, out_file)))
		val.columns = ['Shannon Entropy']

	os.remove(inp_file)
	os.remove(out_file)

	return val

def Extract_all_PFeats(seq):
	feats = ['atc', 'boc', 'ddor', 'pcp', 'rri', 'sep', 'ser', 'se']
	results = []
	for f in feats:
		results.append(Pfeat(seq, f))
	return pd.concat(results, axis=1)


def iFeat(seq, feat):
	advanced_descs = ['CKSAAP', 'CKSAAGP', 'KSCTriad']

	inp_file = write_seq_to_file_2(seq)
	outFile = inp_file.replace('fasta','tsv')
 
	myOrder = 'ACDEFGHIKLMNPQRSTVWY'
	kw = {'path': None, 'train': None, 'label': None, 'order': myOrder}

	if feat not in advanced_descs:
		fastas = readFasta.readFasta(inp_file)
		myFun = feat + '.' + feat + '(fastas, **kw)'
		encodings = eval(myFun)
		saveCode.savetsv(encodings, outFile)
  
	elif feat in advanced_descs:
		fastas = readFasta.readFasta(inp_file)
		gap = 5
  
		if feat == 'CKSAAP':
			myFun = '{}.{}(fastas, {}, **kw)'.format(feat, feat, gap)
   
		elif feat == 'CKSAAGP' or feat == 'KSCTriad':
			myFun = '{}.{}(fastas, {})'.format(feat, feat, gap)
   
		encodings = eval(myFun)
		saveCode.savetsv(encodings, outFile)
	
	val = pd.read_csv(outFile, sep='\t', header=0)
	val = val.drop(['#'], axis=1)
 
	os.remove(inp_file)
	os.remove(outFile)
	return val

def Extract_all_iFeats(seq):
	feats = ['AAC', 'CKSAAP', 'DDE', 'GAAC', 'CKSAAGP', 'GDPC', 'GTPC', 
			'Moran', 'Geary', 'NMBroto', 'CTDC', 'CTDT', 'CTDD', 'KSCTriad', 
			'SOCNumber', 'QSOrder', 'PAAC', 'APAAC']
     
	results = []
	for f in feats:
		results.append(iFeat(seq, f))
	return pd.concat(results, axis=1)

def Extract_all(seq):
    results = []
    results.append(Extract_all_iFeats(seq))
    results.append(Extract_all_PFeats(seq))
    res = pd.concat(results, axis=1)
    res = res.astype('float')
    return res


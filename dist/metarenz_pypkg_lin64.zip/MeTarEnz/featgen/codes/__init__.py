#!/usr/bin/env python
#_*_coding:utf-8_*_

__all__ = ['readFasta','saveCode', 'checkFasta','AAINDEX',  'AAC', 'CKSAAP', 'DDE', 'GAAC', 'CKSAAGP', 'GDPC', 'GTPC','Moran', 'Geary', 'NMBroto', 'CTDC', 'CTDT', 'CTDD', 'KSCTriad', 'SOCNumber', 'QSOrder', 'PAAC', 'APAAC']


